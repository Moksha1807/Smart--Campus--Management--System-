# SMART CAMPUS MANAGEMENT SYSTEM
import os

students = []
courses = []

def register_student():
    sid = int(input("Enter Student ID: "))
    name = input("Enter Student Name: ")
    age = int(input("Enter Age: "))
    marks = float(input("Enter Marks (0-100): "))

    if marks >= 90:
        grade, remark = "A", "Excellent"
    elif marks >= 75:
        grade, remark = "B", "Very Good"
    elif marks >= 60:
        grade, remark = "C", "Good"
    elif marks >= 40:
        grade, remark = "D", "Average"
    else:
        grade, remark = "F", "Needs Improvement"

    students.append({
        "id": sid, "name": name, "age": age,
        "marks": marks, "grade": grade, "remark": remark
    })

def display_students():
    for s in students:
        print(s)

while True:
    print("\\nSMART CAMPUS MANAGEMENT SYSTEM")
    print("1. Register Student")
    print("2. Display Students")
    print("3. Exit")

    choice = input("Enter choice: ")

    if choice == "1":
        register_student()
    elif choice == "2":
        display_students()
    elif choice == "3":
        break
