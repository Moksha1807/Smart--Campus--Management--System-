# Smart Campus Management System

Python mini-project integrating:
- Student Registration
- Grade Evaluation
- Course Enrollment
- Record Management
- Searching & Sorting
- Fee Calculation
- File Handling
- Directory Scanning
- Performance Analytics

Author: Moksha1807
